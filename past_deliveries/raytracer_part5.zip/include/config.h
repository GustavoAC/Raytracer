#pragma once
#include <string>

const static std::string G_PROJECT_NAME = "raytracer";