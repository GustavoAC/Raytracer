#include "aggregatePrimitive.h"

class BVHAccel : public AggregatePrimitive {
 private:
  /* data */
 public:
  BVHAccel(/* args */);
};
