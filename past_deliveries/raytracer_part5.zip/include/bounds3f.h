#include "ray.h"
#include "vec3.h"

class Bounds3f {
 private:
  point3 pMin;
  point3 pMax;

 public:
  Bounds3f(const vec3 &pMin, const vec3 &pMax) : pMin(pMin), pMax(pMax) {}
  bool intersect(const Ray &r, float &hit1, float &hit2) {}
};
