#pragma once

class Light {};
