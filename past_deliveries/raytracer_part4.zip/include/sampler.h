#pragma once

class Sampler {};
